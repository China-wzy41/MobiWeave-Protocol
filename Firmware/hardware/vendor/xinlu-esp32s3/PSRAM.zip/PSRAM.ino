void setup() {
  Serial.begin(115200);
  delay(500);

  if (psramFound()) {
    Serial.println("✅ PSRAM 已开启");
    Serial.print("总大小：");
    Serial.println(ESP.getPsramSize());
    Serial.print("剩余大小：");
    Serial.println(ESP.getFreePsram());
  } else {
    Serial.println("❌ PSRAM 未开启");
  }
}

void loop() {}